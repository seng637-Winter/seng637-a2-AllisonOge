package org.jfree.data.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

import java.security.InvalidParameterException;

import org.jfree.data.DataUtilities;
import org.jfree.data.Values2D;
import org.jmock.Expectations;
import org.jmock.Mockery;
import org.junit.Before;
import org.junit.Test;


public class CalculateRowTotalTest {
	private Mockery context;
	
	@Before
	public void setUp() throws Exception { context = new Mockery(); }

	/**
     * Tests for the {@link DataUtilities#calculateRowTotal(Values2D, int)} method.
     * 
     * The following test cases apply black box testing techniques
     * to ensure comprehensive testing of the calculateRowTotal method's behavior across
     * a range of valid and invalid input scenarios. The tests cover equivalence partitioning,
     * boundary value analysis, and decision table strategies to validate the method's
     * correctness and robustness in handling row total calculations.
     */
    @Test
    public void testValidInput() {
        final Values2D data = context.mock(Values2D.class); // Initialize with a mock
        final int row = 1; 
        final double expected = 10.0; // Expected sum
        
        // Define expectations
        context.checking(new Expectations() {{
        	oneOf(data).getColumnCount();
        	will(returnValue(2)); // assuming a 2 column data for simplicity
        	oneOf(data).getValue(row, 0);
        	will(returnValue(5.0));
        	oneOf(data).getValue(row, 1);
        	will(returnValue(5.0));
        }});
        
        assertEquals("Sum should match the expected value for a valid row index.",
                expected, DataUtilities.calculateRowTotal(data, row), 0.001d);
    }

    @Test
    public void testRowOutOfBounds() {
        final Values2D data = context.mock(Values2D.class); // Initialize with a mock
        final int row = -1; // Or any invalid index, e.g., greater than the number of columns.
        final double expected = 0.0;
        
     // Define expectations
        context.checking(new Expectations() {{
        	allowing(data).getColumnCount();
        	will(returnValue(3)); // assuming getColumnCount is used to determine the number of columns
        	
        	// handle out-of-bounds access by ignoring any attempt to access it
        	ignoring(data).getValue(with(equal(row)), with(any(Integer.class)));
        }});
        assertEquals("Attempting to calculate the total for a row index out of bounds should return 0.",
                     expected, DataUtilities.calculateRowTotal(data, row), 0.001d);
        context.assertIsSatisfied();
    }

    @Test
    public void testNullData() {
    	try {
    		DataUtilities.calculateRowTotal(null, 0);
    		fail("Expected an InvalidParameterException to be thrown");
    	} catch (InvalidParameterException e) {
    		// exception is expected and test passes
    	} catch (Throwable t) {
    		fail("Expected an InvalidParameterException, but got " + t.getClass().getSimpleName());
    	}
        
    }

}
