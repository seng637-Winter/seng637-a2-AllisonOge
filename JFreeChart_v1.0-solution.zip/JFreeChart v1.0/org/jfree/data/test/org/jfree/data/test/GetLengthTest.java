package org.jfree.data.test;
import org.jfree.data.Range; 
import static org.junit.Assert.*;
import org.junit.Test;


/**
 * This class tests the {@link Range#getLength()} method.
 */

public class GetLengthTest {


// Test case for the length of a range of positive values
 @Test
    public void testGetLengthPositiveRange() {
        
        Range range = new Range(1.0, 5.0);
        
        
        double expectedLength = 5.0 - 1.0;
        
        assertEquals("Length of the range should be 4.0", expectedLength, range.getLength(), 0.0001);
    }

//Test case for the length of a range of negative values
    @Test
    public void testGetLengthNegativeRange() {

        Range range = new Range(-5.0, -1.0);
        

        double expectedLength = -1.0 - (-5.0);
        

        assertEquals("Length of the range should be 4.0", expectedLength, range.getLength(), 0.0001);
    }

 // Test case for the length of a zero-length range (range with one element)
    @Test
    public void testGetLengthZeroLength() {

        Range range = new Range(0.0, 0.0);
        

        double expectedLength = 0.0;
        

        assertEquals("Length of the range should be 0.0", expectedLength, range.getLength(), 0.0001);
    }
}