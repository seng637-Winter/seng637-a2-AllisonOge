package org.jfree.data.test;

import static org.junit.Assert.*;

import org.jfree.data.Range;
import org.junit.*;


/**
 * Tests for the {@link Range#getUpperBound()} method.
 * 
 * The following test cases apply black box testing techniques
 * to ensure comprehensive testing of the getUpperBound method's behavior across
 * a range of valid and invalid input scenarios. The tests cover equivalence partitioning,
 * boundary value analysis, and decision table strategies to validate the method's
 * correctness and robustness in handling row total calculations.
 */


public class GetUpperBoundTest {

	private Range exampleRange;

    @Before
    public void setUp() throws Exception {
        // Set up the exampleRange object before each test method
        exampleRange = null; // Initialize to null before each test
    }

    
    // Test case for normal range with positive upper bound
    @Test
    public void testgetUpperBoundNormalRangePositive() {
        exampleRange = new Range(-10, 10);
        assertEquals("The upper value of -10 and 10 should be 10",
                10, exampleRange.getUpperBound(), .000000001d);
    }
    
    // Test case for normal range with negative upper bound
    @Test
    public void testgetUpperBoundNormalRangeNegative() {
        exampleRange = new Range(-5, -2);
        assertEquals("The upper value of -5 and -2 should be -2",
                -2, exampleRange.getUpperBound(), .000000001d);
    }
    
    // Test case for range with upper bound at zero
    @Test
    public void testgetUpperBoundRangeWithZeroLowerBound() {
        exampleRange = new Range(-5, 0);
        assertEquals("The upper value of -5 and 0 should be 0",
                0, exampleRange.getUpperBound(), .000000001d);
    }
    
    // Test case for range with only one element
    @Test
    public void testgetUpperBoundRangeWithOneElement() {
        exampleRange = new Range(10, 10);
        assertEquals("The upper value of 10 and 10 should be 10",
                10, exampleRange.getUpperBound(), .000000001d);
    }

    @After
    public void tearDown() throws Exception {
        // Clean up after each test method if necessary
    }

    @AfterClass
    public static void tearDownAfterClass() throws Exception {
        // Clean up after all test methods if necessary
    }

}
