package org.jfree.data.test;

import static org.junit.Assert.*;

import org.jfree.data.Range;
import org.junit.*;

/**
 * Tests for the {@link Range#getLowerBound()} method.
 * 
 * The following test cases apply black box testing techniques
 * to ensure comprehensive testing of the getLowerBound method's behavior across
 * a range of valid and invalid input scenarios. The tests cover equivalence partitioning,
 * boundary value analysis, and decision table strategies to validate the method's
 * correctness and robustness in handling row total calculations.
 */

public class GetLowerBoundTest {

	private Range exampleRange;

    @Before
    public void setUp() throws Exception {
        // Set up the exampleRange object before each test method
        exampleRange = null; // Initialize to null before each test
    }

    // Test case for normal range with positive lower bound
    @Test
    public void testGetLowerBoundNormalRangePositive() {
        exampleRange = new Range(1, 10);
        assertEquals("The lower value of 1 and 10 should be 1",
                1, exampleRange.getLowerBound(), .000000001d);
    }
    
    // Test case for normal range with negative lower bound
    @Test
    public void testGetLowerBoundNormalRangeNegative() {
        exampleRange = new Range(-5, 5);
        assertEquals("The lower value of -5 and 5 should be -5",
                -5, exampleRange.getLowerBound(), .000000001d);
    }
    
    // Test case for range with lower bound at zero
    @Test
    public void testGetLowerBoundRangeWithZeroLowerBound() {
        exampleRange = new Range(0, 10);
        assertEquals("The lower value of 0 and 10 should be 0",
                0, exampleRange.getLowerBound(), .000000001d);
    }
    
    // Test case for range with only one element
    @Test
    public void testGetLowerBoundRangeWithOneElement() {
        exampleRange = new Range(10, 10);
        assertEquals("The lower value of 10 and 10 should be 10",
                10, exampleRange.getLowerBound(), .000000001d);
    }
    
    
    @After
    public void tearDown() throws Exception {
        // Clean up after each test method if necessary
    }

    @AfterClass
    public static void tearDownAfterClass() throws Exception {
        // Clean up after all test methods if necessary
    }
}
