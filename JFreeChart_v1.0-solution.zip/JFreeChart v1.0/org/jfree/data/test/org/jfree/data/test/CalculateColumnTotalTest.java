package org.jfree.data.test;

import static org.junit.Assert.*;

import java.security.InvalidParameterException;

import org.jfree.data.DataUtilities;
import org.jfree.data.Values2D;
import org.jmock.Expectations;
import org.jmock.Mockery;
import org.junit.Before;
import org.junit.Test;

/**
 * Tests for the {@link DataUtilities#calculateColumnTotal(Values2D, int)} method.
 * 
 * The following test cases apply black box testing techniques
 * to ensure comprehensive testing of the calculateColumnTotal method's behavior across
 * a range of valid and invalid input scenarios. The tests cover equivalence partitioning,
 * boundary value analysis, and decision table strategies to validate the method's
 * correctness and robustness in handling row total calculations.
 */
public class CalculateColumnTotalTest {

private Mockery context;
    
    @Before
    public void setUp() throws Exception { context = new Mockery(); }


    @Test
    public void testValidInput() {
        final Values2D data = context.mock(Values2D.class); // Initialize with a mock
        final int column = 1; 
        final double expected = 10.0; // Expected sum
        
        // Define expectations
        context.checking(new Expectations() {{
        	oneOf(data).getRowCount();
        	will(returnValue(2)); // assuming a 2 row data for simplicity
        	oneOf(data).getValue(0, column);
        	will(returnValue(5.0));
        	oneOf(data).getValue(1, column);
        	will(returnValue(5.0));
        }});
        
        assertEquals("The sum of the values in the specified valid column should match the expected result.",
                expected, DataUtilities.calculateColumnTotal(data, column), 0.001d);
    }

    @Test
    public void testColumnOutOfBounds() {
        final Values2D data = context.mock(Values2D.class); // Initialize with a mock
        final int column = -1; // Or any invalid index, e.g., greater than the number of columns.
        final double expected = 0.0;
        
     // Define expectations
        context.checking(new Expectations() {{
        	allowing(data).getRowCount();
        	will(returnValue(3)); // assuming getRowCount is used to determine the number of rows
        	
        	// handle out-of-bounds access by ignoring any attempt to access it
        	ignoring(data).getValue(with(any(Integer.class)), with(equal(column)));
        }});
        assertEquals("Attempting to calculate the total for a column index out of bounds should return 0.",
                     expected, DataUtilities.calculateColumnTotal(data, column), 0.001d);
        context.assertIsSatisfied();
    }

    @Test
    public void testNullData() {
    	try {
    		DataUtilities.calculateColumnTotal(null, 0);
    		fail("Expected an InvalidParameterException to be thrown");
    	} catch (InvalidParameterException e) {
    		// exception is expected and test passes
    	} catch (Throwable t) {
    		fail("Expected an InvalidParameterException, but got " + t.getClass().getSimpleName());
    	}
        
    }

}
