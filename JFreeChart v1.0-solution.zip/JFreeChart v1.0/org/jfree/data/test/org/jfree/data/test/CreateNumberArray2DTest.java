package org.jfree.data.test;

import static org.junit.Assert.assertArrayEquals;

import java.security.InvalidParameterException;

import org.jfree.data.DataUtilities;
import org.junit.Test;

public class CreateNumberArray2DTest {

	/*
	 * Valid Input test to verify that the method correctly converts 2D array
	 * of double primitives to a 2D array of Number objects 
	 */
    @Test
    public void testCreateNumberArray2DValidInput() {
        double[][] validData = {{1.1, 2.2}, {3.3, 4.4}};
        
        Number[][] expected = {{1.1, 2.2}, {3.3, 4.4}};
        
        Number[][] result = DataUtilities.createNumberArray2D(validData);
        
        assertArrayEquals("Valid input should produce expected result", expected, result);
    }

    
    /*
	 * Null Input test to verify that the method throws an InvalidParameterException when 
	 * passed a null input
	 */
    @Test(expected = InvalidParameterException.class) 
    public void testCreateNumberArray2DNullInput() {
        DataUtilities.createNumberArray2D(null);
    }

    
    /*
	 * Empty Array test to verify that the method correctly handles an empty 2D array
	 */
    @Test
    public void testCreateNumberArray2DEmptyInput() {
        double[][] emptyData = {};
        Number[][] expected = {};
        
        Number[][] result = DataUtilities.createNumberArray2D(emptyData);
        assertArrayEquals("Empty array input should produce expected result", expected, result);
    }

    
    /*
	 * Single Element Array test to verify that the method correctly handles
	 * a 2D array with a single element
	 */
    @Test
    public void testCreateNumberArray2DSingleElementArray() {
    	double[][] singleElementData = {{42.0}};
    	Number[][] expected = {{42.0}};
    	
    	assertArrayEquals("Single Element array input should produce expected result", expected, DataUtilities.createNumberArray2D(singleElementData));
    }

    
    /*
	 * Invalid Input test to verify that the method throws an InvalidParameterException when
	 * passed an invalid input array
	 */
    @Test(expected = InvalidParameterException.class) 
    public void testCreateNumberArray2DInvalidInput() {
        
        
        double[][] invalidData = {{1.0, 2.0}, {3.0}};
        
        DataUtilities.createNumberArray2D(invalidData);
    }
    
    /*
	 * Large Numbers test to verify that the method correctly handles a 2D array containing
	 * very large numbers
	 */
    @Test
    public void testCreateNumberArray2DLargeNumbers() {
    	double[][] singleElementData = {{Double.MAX_VALUE, Double.MAX_VALUE}, {-Double.MAX_VALUE, -Double.MAX_VALUE}};
    	Number[][] expected = {{Double.MAX_VALUE, Double.MAX_VALUE}, {-Double.MAX_VALUE, -Double.MAX_VALUE}};
    	
    	assertArrayEquals("Large Number array input should produce expected result", expected, DataUtilities.createNumberArray2D(singleElementData));
    }
}