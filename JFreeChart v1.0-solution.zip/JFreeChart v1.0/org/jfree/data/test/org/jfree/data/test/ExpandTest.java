package org.jfree.data.test;

import static org.junit.Assert.*;
import java.security.InvalidParameterException;

import org.junit.Test;
import org.jfree.data.DataUtilities;
import org.jfree.data.Range;
import org.jfree.data.Values2D;

/**
 * Tests for the {@link Range#expand(Range, double, double)} method.
 * 
 * The following test cases apply black box testing techniques
 * to ensure comprehensive testing of the expand method's behavior across
 * a range of valid and invalid input scenarios. The tests cover equivalence partitioning,
 * boundary value analysis, and decision table strategies to validate the method's
 * correctness and robustness in handling expanded range objects.
 */
public class ExpandTest {
	/*
	 * Expand With Valid Input test to test that the method returns correct result with
	 * valid input
	 */
	@Test
	public void testExpandWithValidInput() {
		Range inputRange = new Range(2, 6);
		Range expectedRange = new Range(1, 8);
		
		Range result = Range.expand(inputRange, 0.25, 0.5);
		assertEquals("Expanded range should match expected output.", expectedRange, result);
	}
	
	/*
	 * Empty Range test to verify that passing empty Range returns the correct expansion
	 */
	@Test
	public void testExpandWithEmptyRange() {
		Range inputRange = new Range(2, 2);
		Range result = Range.expand(inputRange, 0.2, 0.2);
		assertEquals("Range should remain unchanged with same margins and empty range.", inputRange, result);
	}

	/*
	 * Negative Margins test to test the behaviour when negative margins are passed
	 */
	@Test(expected = InvalidParameterException.class)
	public void testExpandWithInvalidMargin() {
		Range inputRange = new Range(2, 6);
		
		Range.expand(inputRange, -0.25, -0.25);
	}

	/*
	 * Expand With Null Range test to verify that the method throw the InvalidParameterException when a 
	 * null range object is passed
	 */
	@Test(expected = InvalidParameterException.class)
	public void testExpandWithNullRange() {
		Range.expand(null, 0.25, 0.5);
	}
}
