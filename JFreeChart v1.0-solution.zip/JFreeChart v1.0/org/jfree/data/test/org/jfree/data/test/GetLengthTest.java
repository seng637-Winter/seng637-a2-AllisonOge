package org.jfree.data.test;
import org.jfree.data.Range; 
import static org.junit.Assert.*;
import org.junit.Test;

public class GetLengthTest {

 @Test
    public void testGetLengthPositiveRange() {
        
        Range range = new Range(1.0, 5.0);
        
        
        double expectedLength = 5.0 - 1.0;
        
        assertEquals("Length of the range should be 4.0", expectedLength, range.getLength(), 0.0001);
    }

    @Test
    public void testGetLengthNegativeRange() {

        Range range = new Range(-5.0, -1.0);
        

        double expectedLength = -1.0 - (-5.0);
        

        assertEquals("Length of the range should be 4.0", expectedLength, range.getLength(), 0.0001);
    }

    @Test
    public void testGetLengthZeroLength() {

        Range range = new Range(0.0, 0.0);
        

        double expectedLength = 0.0;
        

        assertEquals("Length of the range should be 0.0", expectedLength, range.getLength(), 0.0001);
    }
}