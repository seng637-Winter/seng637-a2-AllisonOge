package org.jfree.data.test;

import org.jfree.data.DataUtilities;
import org.jfree.data.KeyedValues;
import org.jmock.Expectations;
import org.jmock.Mockery;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

/**
 * This class tests the DataUtilities.getCumulativePercentages method to ensure it accurately calculates
 * cumulative percentages for various scenarios including normal datasets, empty datasets,
 * datasets with a single value, datasets with negative values, datasets null value and datasets with zero values.
 */
public class GetCumulativePercentagesTest {
    
    private Mockery context = new Mockery();

    @BeforeClass
    public static void setUpBeforeClass() throws Exception {
    }

    @Before
    public void setUp() throws Exception {
    }

    /**
     * Tests cumulative percentages calculation on a normal dataset.
     * Expected to pass if the method correctly calculates cumulative percentages.
     */
    @Test
    public void testCumulativePercentagesNormalDataset() {
        final KeyedValues values = context.mock(KeyedValues.class);

        context.checking(new Expectations() {{
            allowing(values).getItemCount(); will(returnValue(3));
            allowing(values).getValue(0); will(returnValue(1.0));
            allowing(values).getValue(1); will(returnValue(2.0));
            allowing(values).getValue(2); will(returnValue(3.0));
            allowing(values).getKey(0); will(returnValue("A"));
            allowing(values).getKey(1); will(returnValue("B"));
            allowing(values).getKey(2); will(returnValue("C"));
        }});
       
        KeyedValues result = DataUtilities.getCumulativePercentages(values);
        assertEquals("Cumulative percentage of the first item should be 0.17", 0.17, result.getValue("A").doubleValue(), 0.01);
        assertEquals("Cumulative percentage of the second item should be 0.5", 0.5, result.getValue("B").doubleValue(), 0.01);
        assertEquals("Cumulative percentage of the third item should be 1.0", 1.0, result.getValue("C").doubleValue(), 0.01);
    }

    /**
     * Tests cumulative percentages calculation on an empty dataset.
     * Expected to pass if the method correctly returns an empty result for an empty dataset.
     */
    @Test
    public void testCumulativePercentagesEmptyDataset() {
        final KeyedValues values = context.mock(KeyedValues.class);
        context.checking(new Expectations() {{
            allowing(values).getItemCount(); will(returnValue(0));
        }});

        KeyedValues result = DataUtilities.getCumulativePercentages(values);
        assertEquals("Result should be empty for an empty input dataset", 0, result.getItemCount());
    }

    /**
     * Tests cumulative percentages calculation on a dataset with a single value.
     * Expected to pass if the method correctly calculates 100% for the single value.
     */
    @Test
    public void testCumulativePercentagesSingleValue() {
        final KeyedValues values = context.mock(KeyedValues.class);
        context.checking(new Expectations() {{
            allowing(values).getItemCount(); will(returnValue(1));
            allowing(values).getValue(0); will(returnValue(5.0));
            allowing(values).getKey(0); will(returnValue("A"));
        }});

        KeyedValues result = DataUtilities.getCumulativePercentages(values);
        assertEquals("Cumulative percentage of a single item should be 1.0", 1.0, result.getValue("A").doubleValue(), 0.01);
    }

    /**
     * Tests cumulative percentages calculation on a dataset with negative values.
     * Expected to pass if the method correctly handles negative values in the calculation.
     */
    @Test
    public void testCumulativePercentagesWithNegativeValues() {
        final KeyedValues values = context.mock(KeyedValues.class);
        context.checking(new Expectations() {{
            allowing(values).getItemCount(); will(returnValue(3));
            allowing(values).getValue(0); will(returnValue(-1.0));
            allowing(values).getValue(1); will(returnValue(2.0));
            allowing(values).getValue(2); will(returnValue(3.0));
            allowing(values).getKey(0); will(returnValue("A"));
            allowing(values).getKey(1); will(returnValue("B"));
            allowing(values).getKey(2); will(returnValue("C"));
        }});

        KeyedValues result = DataUtilities.getCumulativePercentages(values);
        assertEquals("Cumulative percentage of 'A' with negative value", -0.25, result.getValue("A").doubleValue(), 0.01);
        assertEquals("Cumulative percentage of 'B'", 0.25, result.getValue("B").doubleValue(), 0.01);
        assertEquals("Cumulative percentage of 'C'", 1.0, result.getValue("C").doubleValue(), 0.01);
    }

    /**
     * Tests cumulative percentages calculation on a dataset with zero values.
     * Expected to pass if the method correctly calculates cumulative percentages, handling zero values properly.
     */
    @Test
    public void testCumulativePercentagesWithZeroValues() {
        final KeyedValues values = context.mock(KeyedValues.class);
        context.checking(new Expectations() {{
            allowing(values).getItemCount(); will(returnValue(3));
            allowing(values).getValue(0); will(returnValue(0.0));
            allowing(values).getValue(1); will(returnValue(2.0));
            allowing(values).getValue(2); will(returnValue(2.0));
            allowing(values).getKey(0); will(returnValue("A"));
            allowing(values).getKey(1); will(returnValue("B"));
            allowing(values).getKey(2); will(returnValue("C"));
        }});

        KeyedValues result = DataUtilities.getCumulativePercentages(values);
        assertEquals("Cumulative percentage of zero value should be 0.0", 
                     0.0, result.getValue("A").doubleValue(), 0.01);
        assertEquals("Cumulative percentage progression should correctly handle zero values", 
                     0.5, result.getValue("B").doubleValue(), 0.01);
        assertEquals("Final cumulative percentage should be 1.0 including zero values", 
                     1.0, result.getValue("C").doubleValue(), 0.01);
    }
    
    @Test(expected = IllegalArgumentException.class) 
    public void testCumulativePercentagesWithNullInput() {
        KeyedValues result = DataUtilities.getCumulativePercentages(null);
    }

    @After
    public void tearDown() throws Exception {
        context.assertIsSatisfied(); // Verify that all expectations were met
    }

    @AfterClass
    public static void tearDownAfterClass() throws Exception {
    }
}
