package org.jfree.data.test;

import static org.junit.Assert.*;
import org.jfree.data.Range;
import org.junit.*;

/**
 * Test class for Range.shift method.
 */
public class ShiftTest {
    private Range exampleRange;

    @BeforeClass
    public static void setUpBeforeClass() throws Exception {
    }

    @Before
    public void setUp() throws Exception {
    }

    // Tests for Range.shift with explanations
    
    /**
     * Test shifting a positive range by a positive delta.
     * This test is based on Equivalence Partitioning.
     */
    @Test
    public void testPositiveRangeWithPositiveDelta() {
        exampleRange = new Range(1, 5);
        Range result = Range.shift(exampleRange, 2);
        assertEquals("Shifting a positive range by a positive delta",
                new Range(3, 7), result);
    }

    /**
     * Test shifting a positive range by a negative delta.
     * This test is based on Equivalence Partitioning.
     */
    @Test
    public void testPositiveRangeWithNegativeDelta() {
        exampleRange = new Range(1, 5);
        Range result = Range.shift(exampleRange, -1);
        assertEquals("Shifting a positive range by a negative delta",
                new Range(0, 4), result);
    }

    /**
     * Test shifting any range by zero.
     * This test is based on Equivalence Partitioning.
     */
    @Test
    public void testShiftWithZeroDelta() {
        exampleRange = new Range(-5, 5);
        Range result = Range.shift(exampleRange, 0);
        assertEquals("Shifting with zero delta should result in the same range",
                exampleRange, result);
    }
    
    

    /**
     * Test shifting a positive range to prevent zero crossing.
     * This test is based on Boundary Value Analysis (BVA).
     */
    @Test
    public void testPositiveRangePreventingZeroCrossing() {
        Range exampleRange = new Range(1, 3);
        Range result = Range.shift(exampleRange, -2, false);
        assertEquals("Shifting a positive range to prevent zero crossing should set lower bound to 0",
            new Range(0, 1), result);
    }



    /**
     * Test shifting with a null base range.
     * This test uses Error Guessing (EG) as it anticipates a common error scenario.
     */
    @Test(expected = NullPointerException.class) // Update this to the specific exception thrown by your method
    public void testShiftWithNullBaseRange() {
        Range.shift(null, 1, true);
    }

    @After
    public void tearDown() throws Exception {
    }

    @AfterClass
    public static void tearDownAfterClass() throws Exception {
    }
}
