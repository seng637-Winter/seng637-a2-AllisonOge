package org.jfree.data.test;
import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.fail;
import java.security.InvalidParameterException;
import org.jfree.data.DataUtilities;

import org.junit.Test;


public class CreateNumberArrayTest {
	
	

	@Test
	public void testCreateNumberArray() {
        double[] testData = {4.7, 2.5, 6.8};
        Number[] expected = {4.7, 2.5, 6.8};

        Number[] result = DataUtilities.createNumberArray(testData);

        assertArrayEquals("The number array should equal {4.7, 2.5, 6.8}",
        		expected, result);
        
    }
	
	@Test
    public void testCreateNumberArrayNullData() {
		double[] testData = null;
		
		try {
			DataUtilities.createNumberArray(testData);
			 fail("Expected an InvalidParameterException to be thrown");
			 } catch (InvalidParameterException e) {
			 // exception is expected and test passes
			 } catch (Throwable t) {
			 fail("Expected an InvalidParameterException, but got " + t.getClass
			().getSimpleName());
			 }
    }

    @Test(expected = InvalidParameterException.class)
    public void testCreateNumberArrayEmptyData() {
        double[] testData = {};

        DataUtilities.createNumberArray(testData);
        
        
        
    }
    
    
}